package com;


import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.util.ArrayList;
import java.util.Iterator;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import org.w3c.dom.Document;

import org.w3c.dom.Element;

/*
 * 1. Convert XSL file into XML file.
 * 2. Convert XSL file into JSON file.
 * 3. @param input : XSL File i.e. input.xls
 * 4. @param output : XML File and JSON File i.e. employee.xml and employee.json
 */


public class ConvertFileXslToXml 
{
	 POIFSFileSystem fileSystem = null;
    
	 /* 
		 * 1. Reading XSL file.
		 * 2. To read any XSL file in java Apache POI Library is used.
		 * 3. Apache POI library includes some concrete classes like HSSFWorkbook,HSSFSheet,XSSFWorkbook and XSSFSheet.
		 * 4. Row and Cell are used to representation of a row and cell in a spreadsheet.
		 * 5. FileNotFoundException and IOException is handle.
		 * 6. Storing data in XML Format using storeDataInXmlFile() method.
		 * 7. TransformerFactory is used to create templates.
		 * 8. DOMSource is acts as a holder for a transformation Source tree in the form of a Document Object Model (DOM) tree.
		 * 9. StreamResult is hold transform result.
		 * 10.ParserConfigurationException and TransformerConfigurationException is indicates a serious configuration error.
	 */
	  
	 	 
	 
	 public void storeDataInXmlFile(String xslSource)
	 {
	    InputStream iStream = null; 
	    try
	    {
	    	iStream = new FileInputStream (xslSource);
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document document = builder.newDocument();
	        Element rootElement = document.createElement("employees");
	        document.appendChild(rootElement);
	        fileSystem = new POIFSFileSystem (iStream);
	        HSSFWorkbook workBook = new HSSFWorkbook (fileSystem);
	        HSSFSheet hssSheet= workBook.getSheetAt (0); 
	        Iterator<?> rowIterator= hssSheet.rowIterator ();

	        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	        while (rowIterator.hasNext ()) 
	        {
	        	HSSFRow hssRow = (HSSFRow) rowIterator.next(); 

	        	
	        	int rowNumber = hssRow.getRowNum ();
	            Iterator<?> cells = hssRow.cellIterator (); 
	            int i=0;
	            ArrayList<String> rowData = new ArrayList<String>();
	            while (cells.hasNext ())
	            {
	            	
	                HSSFCell cell = (HSSFCell) cells.next ();
	                switch (cell.getCellType ())
	                {
	                	case HSSFCell.CELL_TYPE_NUMERIC :
	                	{
	                		System.out.println ("Id: " + cell.getNumericCellValue ());
	                		rowData.add(cell.getNumericCellValue () + "");
	                		break;
	                	}
	                	case HSSFCell.CELL_TYPE_STRING :
	                	{
		                    HSSFRichTextString richTextString = cell.getRichStringCellValue ();
		                    System.out.println ("String: " + richTextString.getString ());
		                    rowData.add(richTextString.getString ());
		                    break;
		                }
	                	default:
	                	{
		                    System.out.println ("Type not supported.");
		                    break;
		                }
	               	               
	            	}
	            } 
	            data.add(rowData);

	        } 
	        int numOfProduct = data.size();
	
	        for (int i = 1; i < numOfProduct; i++)
	        {
	            Element productElement = document.createElement("employee");
	            rootElement.appendChild(productElement);
	            int index = 0;
            
	            for(String s: data.get(i))
	            {
	                String headerString = data.get(0).get(index);
	                if( data.get(0).get(index).equals("image link"))
	                {
	                    headerString = "image_link";
	                }

	                if( data.get(0).get(index).equals("product type"))
	                {
	                	headerString = "product_type";
	                }

	                Element headerElement = document.createElement(headerString);
	                productElement.appendChild(headerElement);
	                headerElement.appendChild(document.createTextNode(s));
	                index++;
	            }

		        TransformerFactory tFactory = TransformerFactory.newInstance();
		
		        Transformer transformer = tFactory.newTransformer();
		        
		        transformer.setOutputProperty
		        (OutputKeys.INDENT, "yes");
		        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
		        DOMSource source = new DOMSource(document);
		        StreamResult result = new StreamResult(new File("C:/Users/scispl023/Downloads/assignment-3/employee1.xml"));
		       
		        transformer.transform(source, result);
		    }
	    }
	    catch(IOException e)
	    {
	        System.out.println(e.getMessage());
	    } 
	    catch (ParserConfigurationException e)
	    {
	        System.out.println(e.getMessage());
	    } 
	    catch (TransformerConfigurationException e)
	    {
	        System.out.println(e.getMessage());
	    } 
	    catch (TransformerException e)
	    {
	        System.out.println(e.getMessage());
	    }
	 }
	 /*
	  * 1. Reading xls and converting in JSON.
	  * 2. input: input.xls
	  * 3. output: employee1.json
	  * 4. Use ArrayList of string to store data and then iterate it.
	  * 5. Use Cell and Row to get values from excel sheet.
	  */
		 
	 public void readJSON(String sourceFileName,String destinationFileName)
	    {
	        PrintWriter pw1 = null; 
	        try
	        {
	        	pw1 =  new PrintWriter(new FileWriter(destinationFileName ));
	            pw1.println("{");
	            pw1.println("\t employees  : [ ");
	        
	            FileInputStream file=new FileInputStream(new File(sourceFileName));
	            
	            
	            @SuppressWarnings("resource")
	            HSSFWorkbook workbook = new HSSFWorkbook(file);
	            HSSFSheet sheet = workbook.getSheetAt(0);
	            ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	            Iterator<Row> rowIterator = sheet.iterator();
	            while (rowIterator.hasNext()) 
	            {
	                Row row = rowIterator.next();
                    Iterator<Cell> cellIterator = row.cellIterator();
	                ArrayList<String> rowData = new ArrayList<String>();
	             
	                pw1.println("\t\t\t{  ");
	                Cell cell = cellIterator.next();
	                pw1.println("\t\t\t"+" \"id\"" + " : \t\""+cell.getRow().getCell(0)+ "\" ,");
	                pw1.println("\t\t\t"+" \"name\""+" : \t\""+cell.getRow().getCell(1)+ "\" ,");
	                pw1.println("\t\t\t"+"\"department\"" + " : \t\""+cell.getRow().getCell(2)+ "\" ,");
	                pw1.println("\t\t\t"+"\"city\""+": \t\""+cell.getRow().getCell(3)+"\",");
	                pw1.println("\t\t\t\"designation\" : \t\""+cell.getRow().getCell(4)+ "\" ,");
	                pw1.println("\t\t\t},");                                                         
	                switch (cell.getCellType()) 
	                {
	                 	case Cell.CELL_TYPE_STRING:
	                    {
	                    	@SuppressWarnings("unused")
	                        HSSFRichTextString richTextString = (HSSFRichTextString) cell.getRichStringCellValue ();
	                        System.out.println(cell.getRow().getCell(0));
	                        System.out.println(cell.getRow().getCell(1));
	                        System.out.println(cell.getRow().getCell(2));
	                        System.out.println(cell.getRow().getCell(3));
	                        break;
	                    }
	               }
	               data.add(rowData);
                   System.out.println("");
	                 
	            }
	             pw1.println("\t\t \t  }...  ");
	              pw1.println("\t \t\t\t   ] ");
	              pw1.println("}");
	              pw1.close();
	              System.out.println("Done..");
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	    }
	 
	 
	public static void main (String[] args) throws IOException
	{
		ConvertFileXslToXml cnf = new  ConvertFileXslToXml ();
		  /* -------------------  Calling readJSON() to convert xls into xml format ------------------------------ */
		
	    String xlsPath ="C:/Users/scispl023/Downloads/assignment-3/input.xls";
	    cnf.storeDataInXmlFile (xlsPath);
	  
	    /* -------------------  Calling readJSON() to convert xls into json format ------------------------------ */
	    
	    String source="C:/Users/scispl023/Downloads/assignment-3/input.xls";
	    String destination="C:/Users/scispl023/Downloads/assignment-3/employee1.json";
	    cnf.readJSON(source, destination);
	    
	   
	}

}