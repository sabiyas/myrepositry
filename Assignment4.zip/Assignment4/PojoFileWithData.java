package com;


public class PojoFileWithData
{
    private String e_id;
    private String e_name;
    private String department;
    private String city;
    private  String designation;

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("************************************");
        sb.append("\nemployeeId: ").append(e_id);
        sb.append("\nemployeeName: ").append(e_name);
        sb.append("\ndepartment: ").append(city);
        sb.append("\ndesignation: ").append(department);
        sb.append("\ncity: ").append(designation);
        sb.append("\n************************************");
        return sb.toString();
    }

    public String getEmployeeID()
    {
        return e_id;
    }


    public void setEmployeeID(String employeeID)
    {
        this.e_id = employeeID;
    }


    public String getEmployeeName()
    {
        return e_name;
    }


    public void setEmployeeName(String employeeName)
    {
        this.e_name = employeeName;
    }


    public String getDepartment()
    {
        return department;
    }


    public void setDepartment(String department)
    {
        this.department = department;
    }


    public String getCity()
    {
        return city;
    }


    public void setCity(String city)
    {
        this.city = city;
    }


    public String getDesignation()
    {
        return designation;
    }


    public void setDesignation(String designation)
    {
        this.designation = designation;
    }
}
