package com;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;

import com.google.gson.Gson;

import java.util.*;

/**
 * Convert Xls file into JSON format.
 * input: input.xls
 * output: employee1.json
 * Use external java library i.e. Gson
 * Use pojo class i.e. PojoFileWithData who store all setter and getter methods for file's attributes.
  */
public class ConvertXlsToJson
{
    PrintWriter pw1 = null;
    PojoFileWithData []pj;

    /**
     * USe HSSFWorkbook,HSSFSheet, Cell and Row to convert excel data.
     * @param sourceFileName: It is xls file i.e. input.xls.
     * @param destinationFileName: It is converted file which is employee1.json.
     * readJSON() method returns emp object who store excel data into list.
     * Handle exception like FileNotFoundException and IOException.
     */

    public List<PojoFileWithData> readJSON(String sourceFileName,String destinationFileName)
    {
        List<PojoFileWithData> emp=new ArrayList<PojoFileWithData>();

        try
        {
            pw1 =  new PrintWriter(new FileWriter(destinationFileName ));
            FileInputStream file=new FileInputStream(new File(sourceFileName));
            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheetAt(0);
            ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
            Iterator<Row> rowIterator = sheet.iterator();
            pj =new PojoFileWithData[13];

            while (rowIterator.hasNext())
            {
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                ArrayList<String> rowData = new ArrayList<String>();
                Cell cell = cellIterator.next();
                pj[cell.getRowIndex()]=new PojoFileWithData();

                pj[cell.getRowIndex()].setEmployeeID(cell.getRow().getCell(0).toString());
                pj[cell.getRowIndex()].setEmployeeName(cell.getRow().getCell(1).toString());
                pj[cell.getRowIndex()].setCity(cell.getRow().getCell(2).toString());
                pj[cell.getRowIndex()].setDepartment(cell.getRow().getCell(3).toString());
                pj[cell.getRowIndex()].setDesignation(cell.getRow().getCell(4).toString());
           }
            System.out.print("List Data: \n");
            for(int i=1;i<13;i++)
            {
                emp.add(pj[i]);
            }
            System.out.print(emp+"\n");
            file.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return (emp);
    }

    /**
     * readListToMap() method used to store list data into hashmap.
     * @param list takes object of PojoFileWithData and convert into json.
     * list object store data into hashmap object using Map.
     * Gson library is used to convert map object into json.
     */
    public void readListToMap(List list)
    {
        Map<String, List> map=new HashMap<String, List>();
        try
        {
            map.put("employees",list);
            System.out.println("Map data: \n"+map);
            Gson g=new Gson();
            String jsonInString = g.toJson(map);
            System.out.println("Data :"+jsonInString);
            pw1.write(jsonInString.toString());
         }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        pw1.close();
    }

    public static void main (String[] args)
    {
        ConvertXlsToJson cnf = new  ConvertXlsToJson ();
        String source="C:/Users/scispl023/Downloads/assignment-4/input.xls";
        String destination="C:/Users/scispl023/Downloads/assignment-4/employee1.json";
        List list=cnf.readJSON(source, destination);
        cnf.readListToMap(list);
    }
}
