package com;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;

import java.net.URL;

import java.nio.charset.Charset;


public class GetWeatherDataFromLatAndLog
{

    /**
     * This method is used for reading the city name from console
     * And converting it into Latitude and longititude
     * And returnig the Latitude and longititude
     * @param city
     * @return
     */

    public String[] readFromConsole(String city)
    {
        String latLongs[]=new String[2];
        try
        {
            GetLatAngLog getLatLog = new GetLatAngLog();
            latLongs = getLatLog.getLatLongPositions(city);
            System.out.println("Latitude: "+latLongs[0]+" and Longitude: "+latLongs[1]+"\t"+"City :"+city);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return latLongs;
    }

    /**
     * This function is used to add the city and Date to the Web Service
     * @param url
     * @param latlong
     * @return
     */
    public String urlAdd(String url, String[] latlong)
    {
        url=url+latlong[0]+","+latlong[1];
        return url;
    }

    /**
     * This method is used for reading the data from JSON String
     * @param url
     * @return
     * @throws IOException
     */

    public static JSONObject readJsonFromUrl(String url) throws IOException,JSONException
    {
        InputStream is = new URL(url).openStream();
        try
        {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        }
        finally
        {
            is.close();
        }
    }

    /**
     * This function is called by readJsoonFromUrl()
     * for iteration purpose to read data from JSONObject
     * @param rd
     * @return
     * @throws IOException
     */

    private static String readAll(Reader rd) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1)
        {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    /**
     * data object store only weather data for perticular city.
     * @param json
     */
    public void displayWeatherData(JSONObject json)
    {
        try
        {
            String data = json.getString("currently");
            data=data.replace("{","");
            data=data.replace("}","");
            //System.out.println(json.toString());
            String[] data1=data.split(",");
            System.out.println("The Weather data : ");
            for(int i = 0 ; i < data1.length ; i++)
            {
                System.out.println(data1[i]);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    /**
     * url is used to get weather data which is in json form usin Apikey.
     * @param args
     * @throws JSONException
     * @throws IOException
     */

    public static void main(String args[])throws JSONException,IOException
    {
        GetWeatherDataFromLatAndLog weatherData = new GetWeatherDataFromLatAndLog();
        String url=("https://api.darksky.net/forecast/074ee73f05b944ecdaee3653f87d2cfd/");
        String[] LatLongArray= weatherData.readFromConsole("pune");
        String newUrl=weatherData.urlAdd(url,LatLongArray);
        JSONObject json = readJsonFromUrl(newUrl);
        weatherData.displayWeatherData(json);
    }
}