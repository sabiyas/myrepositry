package com;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URLEncoder;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;

import flexjson.JSONSerializer;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;

/**
 * This class will get the lat long values.
 * using Google web api.
 */
public class GetLatAngLog
{
    public static String[] getLatLongPositions(String address) throws Exception
    {
        String[] latlong=new String[2];
        try
        {
            String api = "http://maps.googleapis.com/maps/api/geocode/json?address=" + URLEncoder.encode(address, "UTF-8") + "&sensor=true";
            URL url = new URL(api);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200)
            {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            String output = "", full = "";
            while ((output = br.readLine()) != null)
            {
               // System.out.println(output);
                full += output;
            }
            conn.disconnect();

            JSONObject object=new JSONObject(full.toString());
            JSONArray result = object.getJSONArray("results");
            JSONObject result1 = result.getJSONObject(0);
            JSONObject geometry = result1.getJSONObject("geometry");
            JSONObject locat = geometry.getJSONObject("location");
            String lat = locat.getString("lat");
            String lng = locat.getString("lng");
            latlong[0]=lat;
            latlong[1]=lng;
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return latlong;
    }
}