package com.client;

import com.controller.StudentController;

import com.domain.Student;

import java.util.Scanner;

public class MainObjectCalling
{
    public static void main(String args[]) throws Exception
    {
        int choice;
        boolean result;
        Scanner scanner = new Scanner(System.in);
        StudentController studentController = new StudentController();

        do
        {
            System.out.println("*********Menu********");
            System.out.println("1.create \n 2.Update \n 3.Delete \n 4.List \n 5.Exit");
            System.out.println("Enter your choice");
            int ch = scanner.nextInt();
            Student student;
            switch (ch)
            {
                case 1:
                    int student_id=studentController.generateNewStudentId();

                    student = studentController.getDetails(student_id);
                    result = studentController.create(student);
                    studentController.show(student);
                    break;

                case 2:
                    System.out.println("Enter Student Id for which you want to update the student Details:-");
                    int studentId1= scanner.nextInt();
                    student = studentController.getDetails(studentId1);
                    studentController.update(student);
                    studentController.show(student);
                    break;

                case 3:
                    result = studentController.delete();
                    break;

                case 4:
                    studentController.list();
                    break;

                case 5:
                    return;
                default:
                    System.out.println("Please Enter Valid Choice...");
            }
            System.out.println("To continue menu press 1...");
            choice = scanner.nextInt();
        } while (choice == 1);
    }
}
