package com.domain;


/**
 * ClassDetails contains only setters ,getters and toString().
 */
public class ClassDetails
{
    private String division;
    private String standard;
    private  int class_id;

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public int getClass_id() {
        return class_id;
    }

    public void setClass_id(int class_id) {
        this.class_id = class_id;
    }

    @Override
    public String toString() {
        return "ClassDetails{" +
                "division='" + division + '\'' +
                ", standard='" + standard + '\'' +
                ", class_id=" + class_id +
                '}';
    }
}
