package com.domain;

/**
 * Student class contains only setters ,getters and toString().
 */
public class Student
{

    private int student_id;
    private String first_name;
    private String last_name;
    private String contact_mobile;
    private String date_of_birth;
    private int class_id;

    public int getClass_id() {
        return class_id;
    }

    public void setClass_id(int class_id) {
        this.class_id = class_id;
    }

    public ClassDetails classObj;

    public ClassDetails getClassObj() {
        return classObj;
    }

    public void setClassObj(ClassDetails classObj) {
        this.classObj = classObj;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getContact_mobile() {
        return contact_mobile;
    }

    public void setContact_mobile(String contact_mobile) {
        this.contact_mobile = contact_mobile;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    @Override
    public String toString() {
        return "Student{" +
                "student_id=" + student_id +
                ", first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", contact_mobile='" + contact_mobile + '\'' +
                ", date_of_birth='" + date_of_birth + '\'' +
                ", class_id=" + class_id +
                ", classObj=" + classObj +
                '}';
    }
}
