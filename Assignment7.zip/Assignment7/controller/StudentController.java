package com.controller;

import com.domain.Student;

import com.util.CreateConnection;
import java.util.Scanner;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


/**
 * StudentController class contains all operations which are perform on 2 tables i.e. student2 and class1
 *  java.lang.Exception is handle for all operations.
 */

public class StudentController
{

    /**
     * getDetails() take output from user.
     * It calls getClassId() which returns class_id.
     * @return student object.
     */

    public Student getDetails(int student_id)
    {
        Student student=new Student();
        Scanner scanner = new Scanner(System.in);

        int class_id;
        String first_name;
        String last_name;
        String date_of_birth;
        String contact_mobile;
        String division;
        String standard;

        try
        {
            System.out.println("Enter First Name:");
            first_name= scanner.next();
            System.out.println("Enter Last Name:");
            last_name= scanner.next();
            System.out.println("Enter mobile Number :");
            contact_mobile= scanner.next();
            System.out.println("Enter DOB  :");
            date_of_birth= scanner.next();
            System.out.println("Enter Standard:");
            standard=scanner.next();
            System.out.println("Enter Division:");
            division=scanner.next();

            student.setStudent_id(student_id);
            student.setFirst_name(first_name);
            student.setLast_name(last_name);
            student.setContact_mobile(contact_mobile);
            student.setDate_of_birth(date_of_birth);


            class_id=getClassId(standard,division);
            student.setClass_id(class_id);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return student;
    }

    /**
     * generateNewStudentId() its return auto generated Student ID.
     * @return
     */

    public int generateNewStudentId()
    {
        int studentId=0;
        try
        {
            Connection con = CreateConnection.getConnection();
            ResultSet resultSet;
            Statement statement = con.createStatement();
            String queryString = "SELECT student_id FROM student2";
            resultSet = statement.executeQuery(queryString);

            int rowcount = 0;
            if (resultSet.last())
            {
                rowcount = resultSet.getRow();
                resultSet.beforeFirst();
                while(resultSet.next())
                {
                    studentId=resultSet.getInt("student_id");
                }
                resultSet.last();
                studentId=rowcount;
                studentId=studentId+1;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return studentId;
    }

    /**
     * getClassId takes data from class table and find out corresponding classId.
     * @param standard
     * @param division
     * @return classId
     * @throws Exception
     */

    public int getClassId(String standard,String division)throws Exception
    {
        int classId=0;
        Connection con = CreateConnection.getConnection();
        Statement statement = con.createStatement();
        ResultSet resultSet = statement.executeQuery("select class_id from class1 where standard =" + "'" +standard + "'"+" AND division ="+ "'" +division + "'");
        int rowcount = 0;
        if (resultSet.last())
        {
            rowcount = resultSet.getRow();
            resultSet.beforeFirst();
            while(resultSet.next())
            {
                classId=resultSet.getInt("class_id");
            }
            }
            if(rowcount==0)
            {
                classId=generateNewClassId(classId,standard,division);

            }

            if (con != null)
            {
                con.close();
            }
        return classId;
    }

    /**
     * generateNewClassId() generate new classId if it is not present in class table and insert into it.
     * @param class_id
     * @param standard
     * @param division
     * @return class_id
     * @throws Exception
     */

    public int generateNewClassId(int class_id,String standard,String division)throws Exception
    {
        Connection con = CreateConnection.getConnection();
        ResultSet resultSet;
        Statement statement = con.createStatement();
        String queryString = "SELECT class_id,standard,division FROM class1";
        resultSet = statement.executeQuery(queryString);
        resultSet.last();
        class_id=resultSet.getInt("class_id");
        class_id=class_id+1;

        String query = " insert into class1 (class_id,standard, division)"+ " values (?, ?, ?)";
        PreparedStatement preparedStmt = con.prepareStatement(query);
        preparedStmt.setInt (1, class_id);
        preparedStmt.setString (2, standard);
        preparedStmt.setString   (3,division );
        preparedStmt.execute();
        return class_id;
    }


    /**
     * create() creating new record and then store it in database.
     * It is call save() who takes 2 arguments i.e.
     * object of student,
     * string msg through which switch case will call.
     * @param student
     * @return result which show method is runinng correctly or not. It gives boolean value.
     * @throws Exception
     */

    public boolean create(Student student)throws Exception
    {
        boolean result=false;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Do you want to create this record in Database then press (yes/YES) :-");
        String result1=scanner.next();
        if(result1.equals("yes") || result1.equals("YES"))
        {
            result=save(student,"insert");
        }

        return result;
    }

    /**
     * delete particular record from table using student_id.
     * @return
     * @throws Exception
     */

    public boolean delete()throws Exception
    {
        Scanner scanner=new Scanner(System.in);
        String query = "delete from student2 where student_id = ?";
        Connection con= CreateConnection.getConnection();
        System.out.println("Enter the Student Id for which you want to Delete Record :-");
        int studentId=scanner.nextInt();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, studentId);
        ps.execute();
        System.out.println("Record deleted successfully..");
        con.close();
        return false;
    }

    /**
     * list() provide data in tabular format.
     * @throws Exception
     */

    public void list()throws Exception
    {
        Connection con= CreateConnection.getConnection();
        int i=0;
        String queryString = "SELECT student2.student_id,student2.class_id,class1.standard,class1.division,student2.first_name, student2.last_name, student2.contact_mobile, student2.date_of_birth FROM student2 JOIN class1 ON class1.class_id=student2.class_id";
        ResultSet rs;
        Statement stmt = con.createStatement();

        rs = stmt.executeQuery(queryString);

        System.out.println("student_id  \t first_name \t \t \t last_name \t \t contact_mobile \t date_of_birth\t \t \t standard\t\t division");
        System.out.println("=================================================================================================================================");
        while(rs.next())
        {
            i++;
            System.out.print(rs.getInt("student_id") +" \t\t \t\t "+rs.getString("first_name")+" \t \t \t\t\t"+rs.getString("last_name")+"\t\t\t"+rs.getString("contact_mobile")+"\t\t\t"+rs.getDate("date_of_birth")+ "\t \t \t \t" + rs.getString("standard")+"\t \t \t \t" + rs.getString("division"));
            System.out.println();
        }
        System.out.println("Total Records : "+i);
        if (con != null)
        {
            con.close();
        }
}

    /**
     * update() update record in database.
     * It is call save() who takes 2 arguments i.e.
     * object of student,
     * string msg through which switch case will call.
     * @param student
     * @return
     * @throws Exception
     */

    public boolean update(Student student)throws Exception
    {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Do you want to update this record in Database then press (yes/YES) :-");
        String save1=scanner.next();
        if( save1.equals("yes") || save1.equals("YES"))
        {
            save(student,"update");
        }
        return false;
    }

    /**
     * show() showing whole record which present in database.
     * @param student
     */

    public void show(Student student)
    {
        System.out.println(" Show student details: ");
        System.out.println("Student Id : "+student.getStudent_id());
        System.out.println("Class Id : "+student.getClass_id());
        System.out.println("First Name : "+student.getFirst_name());
        System.out.println("Last Name : "+student.getLast_name());
        System.out.println("Contact Mobile : "+student.getContact_mobile());
        System.out.println("Date_of_birth : "+student.getDate_of_birth());


    }

    /**
     * save() has switch case which takes 2 cases.
     * "insert" case for inserting data into student2 table
     * "update" case for updating data into student2 table.
     * @param student
     * @param queryType
     * @return
     */

    public boolean save(Student student, String queryType)
    {
        String query="insert into student2 values(?,?,?,?,?,?)";
        Connection con;
        switch(queryType)
        {
            case "insert":

                try
                {

                    con = CreateConnection.getConnection();
                    PreparedStatement statement = con.prepareStatement(query);

                    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                    int studentId = student.getStudent_id();
                    int classId = student.getClass_id();
                    String first = student.getFirst_name();
                    String last = student.getLast_name();
                    String mobile = student.getContact_mobile();
                    String dob = student.getDate_of_birth();

                    statement.setInt(1, studentId);
                    statement.setInt(2, classId);
                    statement.setString(3, first);
                    statement.setString(4, last);
                    statement.setString(5, mobile);
                    statement.setString(6, dob);
                    int i = statement.executeUpdate();
                    System.out.println(i + " records affected...");

                    if (con != null)
                    {
                        con.close();
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
                System.out.println();
                break;

            case "update":

                try
                {
                    con= CreateConnection.getConnection();

                    String query1 = "update student2 set class_id=?,first_name=?,last_name=?,contact_mobile = ?,date_of_birth=? where student_id = ?";
                    PreparedStatement statement2 = con.prepareStatement(query1);
                    statement2.setInt(1, student.getClass_id());
                    statement2.setString(2, student.getFirst_name());
                    statement2.setString(3, student.getLast_name());
                    statement2.setString(4, student.getContact_mobile());
                    statement2.setString(5, student.getDate_of_birth());
                    statement2.setInt (6,student.getStudent_id());
                    int i1=statement2.executeUpdate();
                    System.out.println(i1 + " records updated....");
                    con.close();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

                break;
        }
        return true;
    }
}
