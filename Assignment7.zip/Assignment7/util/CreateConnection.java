package com.util;

import java.sql.*;

/**
 * All database related connection happens in this class.
 * Singleton object of this class is created.
 */

public class CreateConnection
{
    private static CreateConnection instance;
    private String url="jdbc:mysql://localhost:3306/db";
    private String login="user";
    private String pass="password";

    public static Connection getConnection() throws Exception
    {
        Connection con;
        if (instance == null)
        {
            instance = new CreateConnection();
            System.out.println(" Connection  - - - - - - - -  New DBConnection created");
        }
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection(instance.url, instance.login,instance.pass);
        return  con;
    }

    public static void close(Connection connection)
    {
        try
        {
            if (connection != null)
            {
                connection.close();
                connection=null;
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
