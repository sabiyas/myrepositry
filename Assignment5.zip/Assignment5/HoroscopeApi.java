package com;

import org.json.JSONObject;

import java.io.*;

import java.net.URL;

import java.nio.charset.Charset;

/**
 * Display Horoscope information after hitting URL.
 * Use web services to get information which is in json format.
 * IOException is handle.
 *
 */
public class HoroscopeApi
{
    private static String readAll(Reader rd) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1)
        {
            sb.append((char) cp);
        }
            return sb.toString();
    }

    /**
     *
     * @param url: It is link which holds data in json form.
     * @return json object.
     * @throws IOException
     */
    public static JSONObject readJsonFromUrl(String url) throws IOException
    {
        InputStream is = new URL(url).openStream();
        try
        {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        }
        finally
        {
            is.close();
        }
    }
    public static void main(String[] args)throws IOException
    {
        String url=("http://theastrologer-api.herokuapp.com/api/horoscope");
        url=url+args[0]+"/today";

        JSONObject json = readJsonFromUrl(url);
        String date1 = (String) json.get("date");
        String hscope = (String) json.get("horoscope");
        System.out.println(args[0]+": On Date: "+date1+": "+hscope);
    }
}

