package com;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;


/*
 * 1. Read the Data from XML file.
 * 2. Parse that data.
 * 3. Write into CSV file.
 */


public class ConvertXmltoCsv
{
	
	
	/*
	 * 1. Reading the data using DocumentBuilderFactory,DocumentBuilder and Document.
	 * 2. Use NodeList and Element.
	 * 3. Print data direct into file using printStream.
	 */
	
    BufferedWriter bufferedWriter = null;
	public void readXMLFile() 
	{
		try
		{
			
			File xmlFile = new File("C:/Users/scispl023/Downloads/assignment-2/employees.xml");
			
			//PrintStream out1 = new PrintStream(new FileOutputStream("C:/Users/scispl023/Downloads/assignment-2/employees1.csv"));
			
			File myFile = new File("C:/Users/scispl023/Downloads/assignment-2/employees1.csv");
			Writer writer = new FileWriter(myFile);
			bufferedWriter = new BufferedWriter(writer);
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			
			NodeList nList = doc.getElementsByTagName("employee");
			
			System.out.println("Id"+","+"Name"+","+"Department"+","+"City"+","+"Designation");
			
			//out1.print("Id"+","+"Name"+","+"Department"+","+"City"+","+"Designation"+"\n");
			
			bufferedWriter.write("Id"+","+"Name"+","+"Department"+","+"City"+","+"Designation"+"\n");
						
			for (int temp = 0; temp < nList.getLength(); temp++)
			{
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) 
				{
				
					Element eElement = (Element) nNode;
					
				    System.out.println( eElement.getAttribute("id")+","+eElement.getElementsByTagName("name").item(0).getTextContent()+","+eElement.getElementsByTagName("department").item(0).getTextContent()+","+ eElement.getElementsByTagName("city").item(0).getTextContent()+","+eElement.getElementsByTagName("designation").item(0).getTextContent());
				    
				  // out1.print(eElement.getAttribute("id")+","+eElement.getElementsByTagName("name").item(0).getTextContent()+","+eElement.getElementsByTagName("department").item(0).getTextContent()+","+ eElement.getElementsByTagName("city").item(0).getTextContent()+","+eElement.getElementsByTagName("designation").item(0).getTextContent());
				   // out1.print("\n");
				    				   
		            bufferedWriter.write(eElement.getAttribute("id")+","+eElement.getElementsByTagName("name").item(0).getTextContent()+","+eElement.getElementsByTagName("department").item(0).getTextContent()+","+ eElement.getElementsByTagName("city").item(0).getTextContent()+","+eElement.getElementsByTagName("designation").item(0).getTextContent());
		            bufferedWriter.write("\n");
				} 
			}
			//out1.close();
			bufferedWriter.close();
		}
		catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
		
	}
	
	/*
	 * 1. Use stylesheet to convert XML file in any other file.
	 */
	
	/*public void parseWriteData()
	{
		try
		{
			File stylesheet = new File("C:/Users/scispl023/Downloads/assignment-2/Style.xsl");
	        File xmlSource = new File("C:/Users/scispl023/Downloads/assignment-2/employees.xml");
	
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document document = builder.parse(xmlSource);
	
	        StreamSource stylesource = new StreamSource(stylesheet);
	        Transformer transformer = TransformerFactory.newInstance().newTransformer(stylesource);
	        Source source = new DOMSource(document);
	        StreamResult destination = new StreamResult(new File("C:/Users/scispl023/Downloads/assignment-2/employee1.csv"));
	        transformer.transform(source, destination);
			    
		}
		catch(Exception e)
	    {
	    	e.printStackTrace();
	    }   
	}*/
	
	
	/*
	 * 
	 * Main method to call function.
	 */
	
	public static void main(String args[])
	{
		ConvertXmltoCsv cd=new ConvertXmltoCsv();
		cd.readXMLFile();
		//cd.parseWriteData();
	}
}